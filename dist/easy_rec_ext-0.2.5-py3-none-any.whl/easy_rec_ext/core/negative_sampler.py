# -*- coding: utf-8 -*-
# author: tangj 1844250138@qq.com
# time: 2022/6/29 12:01
# desc:

import os
import random
import logging
import tensorflow as tf

if tf.__version__ >= "2.0":
    tf = tf.compat.v1
filename = str(os.path.basename(__file__)).split(".")[0]


def global_random(item_feas, num, remove_ids=None):
    result = []
    if not remove_ids:
        remove_ids = []
    try_time = 0
    return result
