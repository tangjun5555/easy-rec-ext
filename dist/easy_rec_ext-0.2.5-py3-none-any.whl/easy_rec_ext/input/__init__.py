# -*- coding: utf-8 -*-
# author: tangj 1844250138@qq.com
# time: 2021/7/23 5:38 下午
# desc:

from .csv_input import CSVInput
from .tfrecord_input import TFRecordInput
from .oss_input import OSSInput
