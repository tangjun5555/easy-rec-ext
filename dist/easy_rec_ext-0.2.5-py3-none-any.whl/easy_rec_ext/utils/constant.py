# -*- coding: utf-8 -*-
# author: tangj 1844250138@qq.com
# time: 2022/3/30 10:49 PM
# desc:

SAMPLE_WEIGHT = 'SAMPLE_WEIGHT'
