# -*- coding: utf-8 -*-
# author: tangj 1844250138@qq.com
# time: 2022/6/29 11:15
# desc:


def in_batch_softmax(query_vector, doc_vector):
    pass
