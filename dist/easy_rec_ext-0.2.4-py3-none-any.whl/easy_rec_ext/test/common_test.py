# -*- coding: utf-8 -*-
# author: tangj 1844250138@qq.com
# time: 2022/6/15 11:15
# desc:

import tensorflow as tf

if tf.__version__ >= "2.0":
    tf = tf.compat.v1

line_sep = "\n###############################\n"


def test_04():
    print(line_sep)
    t1 = tf.constant(
        value=[
            ["-1"],
            ["0"],
            ["1"],
            ["100"],
            ["1225875"]
        ],
        dtype=tf.dtypes.string,
    )
    r1 = tf.string_to_number(t1, tf.dtypes.int64)
    print(r1)


def test_03():
    print(line_sep)
    from easy_rec_ext.utils import string_ops

    vocab_list = ["a", "b", "c", "d"]
    t1 = tf.constant(
        value=[
            ["a"],
            ["b"],
            ["d"],
            ["c"],
            ["e"]
        ],
        dtype=tf.dtypes.string,
    )
    t2 = tf.constant(
        value=[
            ["a", "b"],
            ["b", "c"],
            ["d", "e"],
            ["c", "a"],
            ["e", "a"]
        ],
        dtype=tf.dtypes.string,
    )
    print(t1)
    print(t2)
    r1 = string_ops.mapping_by_vocab_list(t1, vocab_list)
    r2 = string_ops.mapping_by_vocab_list(t2, vocab_list)
    print(line_sep)
    print(r1)
    print(line_sep)
    print(r2)


def test_02():
    print("\n###############################")
    t1 = tf.constant(
        value=[
            [1, 2, 3, 4], [4, 3, 2, 1], [5, 6, 7, 8]
        ],
        dtype=tf.dtypes.int32,
    )
    r1 = tf.reverse(t1, [-1])
    print(t1)
    print(r1)


def test_01():
    c = tf.constant([[1, 2, 3, 4], [4, 3, 2, 1], [5, 6, 7, 8]])
    r = tf.math.segment_max(c, tf.constant([0, 0, 1]))
    print(r)
